/**
@page screenshots Screenshots

Here are the mandatory screenshots.

@image html ansi.png
@image html atb-agg.png
@image html benchmark.png
@image html cartoon.png
@image html console.png
@image html cube.png
@image html distance-field-2.png
@image html distance-field-3.png
@image html distance-field.png
@image html embedded-font.png
@image html font.png
@image html gamma.png
@image html glyph.png
@image html harfbuzz.png
@image html harfbuzz-texture.png
@image html lcd.png
@image html markup.png
@image html outline.png
@image html subpixel.png
@image html texture.png

*/
