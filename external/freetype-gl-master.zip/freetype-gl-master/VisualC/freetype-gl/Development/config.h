#define FREETYPE_GL_USE_GLEW 1
/* #undef FREETYPE_GL_USE_VAO */
/* #undef GL_WITH_GLAD */
